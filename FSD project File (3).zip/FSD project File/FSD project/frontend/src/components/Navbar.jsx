import React, { useContext } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import { FaBoxes } from 'react-icons/fa';

const Navbar = () => {
  const { user, logout, loading } = useContext(AuthContext);
  const navigate = useNavigate();
  const location = useLocation();

  // Dynamically adapt colors for the transparent Home page overlay vs solid internal pages
  const isHome = location.pathname === '/';
  const brandText = isHome ? 'text-white' : 'text-[#111111]';
  const linkText = isHome ? 'text-gray-200 hover:text-white' : 'text-[#555555] hover:text-[#2bb6a8]';
  const loginText = isHome ? 'text-white hover:text-gray-200 border-white/20' : 'text-[#555555] hover:text-[#2bb6a8] border-gray-200';
  const logoutClass = isHome ? 'text-red-400 border-red-400 hover:bg-red-400/10' : 'text-red-500 border-red-500 hover:bg-red-50';

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <nav className="bg-transparent sticky top-0 z-50 transition-all -mx-4 px-4 overflow-hidden">
      <div className="container mx-auto px-8 py-4 flex justify-between items-center">

        {/* Logo */}
        <Link to="/" className="text-3xl font-extrabold flex items-center gap-3">
          <FaBoxes className="text-[#2bb6a8]" />
          <span className={`${brandText} tracking-tight transition-colors`}>
            Neighbor<span className="text-[#2bb6a8]">Net</span>
          </span>
        </Link>

        {/* Navigation Items */}
        <div className="hidden md:flex gap-8 items-center">
          <Link to="/browse" className={`${linkText} transition duration-300 font-bold text-base`}>Browse Items</Link>

          {loading ? (
            <div className="w-24"></div>
          ) : user ? (
            <div className="flex items-center gap-8 pl-4">
              <Link to="/dashboard" className={`${linkText} transition duration-300 font-bold text-base`}>Dashboard</Link>
              <Link to="/profile" className="flex items-center gap-2 group">
                <div className="w-9 h-9 rounded-full border-2 border-[#2bb6a8] overflow-hidden transition-transform group-hover:scale-110">
                  <img 
                    src={user.profilePhoto || 'https://cdn-icons-png.flaticon.com/512/149/149071.png'} 
                    alt="P" 
                    className="w-full h-full object-cover"
                  />
                </div>
                <span className={`${linkText} transition duration-300 font-bold text-sm hidden lg:block`}>Profile</span>
              </Link>
              {/* Distinct Logout Button dynamically styled */}
              <button
                onClick={handleLogout}
                className={`bg-transparent border-2 px-6 py-2 rounded-[25px] font-bold transition-all duration-300 hover:scale-105 ml-2 ${logoutClass}`}
              >
                Logout
              </button>
            </div>
          ) : (
            <div className={`flex gap-6 items-center pl-4 border-l ${loginText.split(' ')[2]}`}>
              <Link to="/login" className={`${isHome ? 'text-gray-200 hover:text-white' : 'text-[#555555] hover:text-[#2bb6a8]'} transition duration-300 font-bold text-base`}>Log In</Link>
              <Link to="/register" className="bg-[#2bb6a8] hover:bg-[#229286] text-white px-8 py-2.5 rounded-[25px] font-bold transition-all duration-300 hover:shadow-lg hover:scale-105">
                Sign Up
              </Link>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
