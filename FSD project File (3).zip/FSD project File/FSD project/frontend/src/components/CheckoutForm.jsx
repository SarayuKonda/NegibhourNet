import React, { useState } from 'react';
import { useStripe, useElements, PaymentElement } from '@stripe/react-stripe-js';
import { toast } from 'react-toastify';

const CheckoutForm = ({ clientSecret, onSuccessfulPayment, onCancel, amount }) => {
  const stripe = useStripe();
  const elements = useElements();

  const [message, setMessage] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsLoading(true);

    const { error, paymentIntent } = await stripe.confirmPayment({
      elements,
      redirect: 'if_required', // We don't want to redirect if not necessary
    });

    if (error) {
      if (error.type === 'card_error' || error.type === 'validation_error') {
        setMessage(error.message);
        toast.error(error.message);
      } else {
        setMessage('An unexpected error occurred.');
        toast.error('An unexpected error occurred.');
      }
    } else if (paymentIntent && paymentIntent.status === 'succeeded') {
      toast.success('Payment successful!');
      onSuccessfulPayment(paymentIntent);
    } else {
      setMessage('Something went wrong during payment.');
    }

    setIsLoading(false);
  };

  return (
    <form onSubmit={handleSubmit} className="w-full">
      <PaymentElement id="payment-element" />
      
      {message && <div className="text-red-500 text-sm mt-3 font-semibold">{message}</div>}

      <div className="flex gap-2 mt-5">
        <button
          disabled={isLoading || !stripe || !elements}
          type="button"
          onClick={onCancel}
          className="flex-1 bg-white text-gray-600 border border-gray-200 hover:bg-gray-50 py-2 rounded-lg font-bold text-sm transition-colors"
        >
          Cancel
        </button>
        <button
          disabled={isLoading || !stripe || !elements}
          type="submit"
          className="flex-[2] bg-gradient-to-r from-teal-500 to-cyan-500 text-white hover:opacity-90 py-2 rounded-lg font-bold text-sm transition-colors shadow-sm disabled:opacity-50"
        >
          {isLoading ? (
             <div className="flex justify-center items-center gap-2">
                 <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full"></div>
                 Processing...
             </div>
          ) : (
             `Pay $${amount}`
          )}
        </button>
      </div>
    </form>
  );
};

export default CheckoutForm;
