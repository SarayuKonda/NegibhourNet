import React from 'react';

const ItemCard = ({ item, actionButton }) => {
  return (
    <div className="bg-white rounded-[20px] overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 border border-gray-100 flex flex-col group">
      <div className="relative overflow-hidden h-48">
        <img
          src={item.imageUrl || 'https://via.placeholder.com/400x300?text=Item'}
          alt={item.title}
          className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
        />
        <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold text-gray-700 shadow-sm">
          {item.category}
        </div>
      </div>
      <div className="p-6 flex flex-col flex-grow">
        <div className="flex justify-between items-start mb-1">
          <h3 className="text-xl font-bold text-gray-800 line-clamp-1 flex-1 mr-2">{item.title}</h3>
          <span className={`text-xs font-bold px-3 py-1 rounded-full whitespace-nowrap ${item.status === 'Available' ? 'bg-[#FDBA74]/10 text-[#FDBA74] border border-[#FDBA74]/20' :
            item.status === 'Requested' ? 'bg-cyan-50 text-cyan-600 border border-cyan-200' :
              'bg-gray-100 text-gray-700'
            }`}>
            {item.status}
          </span>
        </div>
        
        <div className="mb-2 flex items-center">
          {item.rating && item.rating > 0 ? (
            <div className="flex items-center text-amber-500 font-bold text-sm bg-amber-50 px-2 py-0.5 rounded-md border border-amber-100">
               <span className="mr-1">⭐</span> {item.rating.toFixed(1)} 
               <span className="text-gray-400 font-normal text-xs ml-1">({item.numReviews} review{item.numReviews !== 1 ? 's' : ''})</span>
            </div>
          ) : (
            <span className="text-xs text-gray-400 italic bg-gray-50 px-2 py-0.5 rounded-md border border-gray-100">No reviews yet</span>
          )}
        </div>
        <p className="text-gray-500 text-sm mb-4 line-clamp-2 flex-grow">{item.description}</p>

        <div className="flex items-center justify-between text-xs text-gray-500 mb-4">
          <div className="flex items-center">
            <span className="font-medium mr-1 text-gray-700">{item.owner?.name}</span>
            â€¢ {item.neighborhood || item.owner?.neighborhood}
          </div>
        </div>

        {/* Pricing Info Badge */}
        <div className="flex flex-wrap gap-2 mb-4">
          <div className="bg-teal-50 border border-teal-100 px-3 py-1 rounded-lg">
            <p className="text-[10px] text-teal-600 font-bold uppercase tracking-wider">Daily Rent</p>
            <p className="text-sm font-extrabold text-teal-700">
              ${item.dailyRate ?? 0}
            </p>
          </div>

          <div className="bg-amber-50 border border-amber-100 px-3 py-1 rounded-lg">
            <p className="text-[10px] text-amber-600 font-bold uppercase tracking-wider">Late Fee</p>
            <p className="text-sm font-extrabold text-amber-700">
              ${item.lateFeePerDay || 0}/day
            </p>
          </div>
        </div>

        <div className="mt-auto">
          {actionButton}
        </div>
      </div>
    </div>
  );
};

export default ItemCard;

