import React from 'react';
import { Link } from 'react-router-dom';
import bgImage from '../assets/background.jpeg';

const Home = () => {
  return (
    <div className="relative flex flex-col justify-start items-center text-center w-full">

      {/* Screen-spanning Background */}
      <div className="fixed inset-0 z-[-1]" style={{ backgroundImage: `url(${bgImage})`, backgroundSize: 'cover', backgroundPosition: 'center', backgroundRepeat: 'no-repeat' }}>
        <div className="absolute inset-0 bg-black/60"></div>
      </div>

      {/* Transparent Main Container pulled starkly upwards */}
      <div className="relative z-10 w-full max-w-4xl bg-transparent p-6 md:p-8 animate-fade-in-up -mt-2 md:-mt-6">

        {/* Heading */}
        <h1 className="text-5xl md:text-[56px] font-extrabold text-white mb-6 tracking-tight leading-tight">
          Share More, <span className="text-[#4fd1c5]">Buy Less.</span>
        </h1>

        {/* Paragraph */}
        <p className="text-lg md:text-xl text-gray-200 mb-8 max-w-2xl mx-auto font-medium leading-relaxed">
          Why buy what you can borrow? NeighborNet connects you with your community to effortlessly share items. Save money, reduce waste, and help your neighbors.
        </p>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-6 justify-center mt-2">
          {/* Primary Button */}
          <Link to="/browse" className="bg-[#2bb6a8] hover:bg-[#229286] text-white font-bold py-3 px-8 rounded-[25px] transition-all transform hover:scale-105 hover:shadow-lg text-lg inline-block">
            Browse Items
          </Link>
          {/* Secondary Button */}
          <Link to="/register" className="bg-transparent hover:bg-white/10 text-white font-bold py-3 px-8 rounded-[25px] border-2 border-white transition-all transform hover:scale-105 hover:shadow-lg text-lg inline-block">
            Join the Community
          </Link>
        </div>

      </div>
    </div>
  );
};

export default Home;
