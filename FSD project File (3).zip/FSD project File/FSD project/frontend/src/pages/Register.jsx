import React, { useState, useContext } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import { toast } from 'react-toastify';

const ALLOWED_EMAIL_DOMAINS = [
  'gmail.com', 'yahoo.com', 'outlook.com', 'hotmail.com',
  'icloud.com', 'protonmail.com', 'zoho.com', 'aol.com',
  'mail.ru', 'yandex.com'
];

const validateEmail = (email) => {
  if (!email) return '';
  const basicFormat = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  if (!basicFormat.test(email)) return 'Please enter a valid email format';
  const domain = email.split('@')[1]?.toLowerCase();
  if (!ALLOWED_EMAIL_DOMAINS.includes(domain)) {
    return `Email must use a valid provider (e.g. gmail.com, yahoo.com, outlook.com)`;
  }
  return '';
};

const validatePhone = (phone) => {
  if (!phone) return '';
  const cleanPhone = phone.replace(/[\s\-\(\)]/g, '');
  if (!/^\d{10}$/.test(cleanPhone)) return 'Phone number must be exactly 10 digits';
  return '';
};

const validatePassword = (password) => {
  if (!password) return '';
  if (password.length < 6) return 'Password must be at least 6 characters';
  return '';
};

const Register = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    neighborhood: '',
    phone: ''
  });
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const { register } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });

    // Validate on change if the field has been touched
    if (touched[name]) {
      const newErrors = { ...errors };
      if (name === 'email') newErrors.email = validateEmail(value);
      if (name === 'phone') newErrors.phone = validatePhone(value);
      if (name === 'password') newErrors.password = validatePassword(value);
      setErrors(newErrors);
    }
  };

  const handleBlur = (e) => {
    const { name, value } = e.target;
    setTouched({ ...touched, [name]: true });

    const newErrors = { ...errors };
    if (name === 'email') newErrors.email = validateEmail(value);
    if (name === 'phone') newErrors.phone = validatePhone(value);
    if (name === 'password') newErrors.password = validatePassword(value);
    setErrors(newErrors);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate all fields before submitting
    const emailError = validateEmail(formData.email);
    const phoneError = validatePhone(formData.phone);
    const passwordError = validatePassword(formData.password);

    if (emailError || phoneError || passwordError) {
      setErrors({ email: emailError, phone: phoneError, password: passwordError });
      setTouched({ email: true, phone: true, password: true });
      toast.error('Please fix the errors before submitting');
      return;
    }

    const result = await register(formData);
    if (result.success) {
      toast.success('Registration successful!');
      navigate('/dashboard');
    } else {
      toast.error(result.message);
    }
  };

  const inputBase = "w-full px-4 py-3 rounded-full border outline-none transition";
  const inputNormal = `${inputBase} border-gray-300 focus:ring-2 focus:ring-teal-500 focus:border-teal-500`;
  const inputError = `${inputBase} border-red-400 focus:ring-2 focus:ring-red-400 focus:border-red-400 bg-red-50/30`;

  return (
    <div className="flex justify-center items-center py-10 min-h-[80vh]">
      <div className="bg-white/40 backdrop-blur-xl border border-white/60 shadow-xl shadow-gray-200/50 w-full max-w-md p-8 rounded-[20px] animate-fade-in-up">
        <h2 className="text-3xl font-extrabold text-center text-gray-900 mb-8">Join NeighborNet</h2>
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
            <input
              type="text"
              name="name"
              className={inputNormal}
              value={formData.name}
              onChange={handleChange}
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
            <input
              type="email"
              name="email"
              placeholder="e.g. yourname@gmail.com"
              className={touched.email && errors.email ? inputError : inputNormal}
              value={formData.email}
              onChange={handleChange}
              onBlur={handleBlur}
              required
            />
            {touched.email && errors.email && (
              <p className="text-red-500 text-xs font-semibold mt-1.5 ml-3">{errors.email}</p>
            )}
          </div>
          <div className="flex gap-4">
              <div className="flex-1">
                <label className="block text-sm font-medium text-gray-700 mb-2">Neighborhood</label>
                <input
                  type="text"
                  name="neighborhood"
                  placeholder="e.g. Downtown"
                  className="w-full px-4 py-3 rounded-[20px] border border-gray-300 focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none transition"
                  value={formData.neighborhood}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="flex-1">
                <label className="block text-sm font-medium text-gray-700 mb-2">Phone No.</label>
                <input
                  type="tel"
                  name="phone"
                  placeholder="e.g. 9876543210"
                  className={touched.phone && errors.phone
                    ? "w-full px-4 py-3 rounded-[20px] border border-red-400 focus:ring-2 focus:ring-red-400 focus:border-red-400 bg-red-50/30 outline-none transition"
                    : "w-full px-4 py-3 rounded-[20px] border border-gray-300 focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none transition"
                  }
                  value={formData.phone}
                  onChange={handleChange}
                  onBlur={handleBlur}
                  required
                />
                {touched.phone && errors.phone && (
                  <p className="text-red-500 text-xs font-semibold mt-1.5 ml-1">{errors.phone}</p>
                )}
              </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Password</label>
            <input
              type="password"
              name="password"
              placeholder="Min. 6 characters"
              className={touched.password && errors.password ? inputError : inputNormal}
              value={formData.password}
              onChange={handleChange}
              onBlur={handleBlur}
              required
            />
            {touched.password && errors.password && (
              <p className="text-red-500 text-xs font-semibold mt-1.5 ml-3">{errors.password}</p>
            )}
          </div>

          <button
            type="submit"
            className="w-full bg-gradient-to-br from-teal-500 to-cyan-500 text-white font-bold py-3 px-4 rounded-full hover:scale-[1.02] hover:opacity-90 transition-all transform shadow-md hover:shadow-lg hover:shadow-teal-500/20"
          >
            Create Account
          </button>
        </form>
        <p className="mt-6 text-center text-gray-600 text-sm">
          Already have an account? <Link to="/login" className="text-teal-500 hover:opacity-80 font-semibold">Log in here</Link>
        </p>
      </div>
    </div>
  );
};

export default Register;


