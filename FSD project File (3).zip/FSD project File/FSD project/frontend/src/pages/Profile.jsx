import React, { useState, useContext, useEffect } from 'react';
import { AuthContext } from '../context/AuthContext';
import { toast } from 'react-toastify';
import api from '../services/api';

const Profile = () => {
  const { user, updateProfile } = useContext(AuthContext);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    neighborhood: '',
    bio: '',
    profilePhoto: ''
  });
  const [stats, setStats] = useState({ items: 0, requests: 0 });

  useEffect(() => {
    if (user) {
      setFormData({
        name: user.name || '',
        phone: user.phone || '',
        neighborhood: user.neighborhood || '',
        bio: user.bio || '',
        profilePhoto: user.profilePhoto || ''
      });
      fetchStats();
    }
  }, [user]);

  const fetchStats = async () => {
    try {
      const itemsRes = await api.get('/items/me');
      const requestsRes = await api.get('/requests');
      setStats({
        items: itemsRes.data.length,
        requests: requestsRes.data.outgoing.length + requestsRes.data.incoming.length
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const result = await updateProfile(formData);
    if (result.success) {
      toast.success('Profile updated successfully!');
      setIsEditing(false);
    } else {
      toast.error(result.message);
    }
  };

  if (!user) return <div className="text-center py-20">Loading...</div>;

  return (
    <div className="max-w-4xl mx-auto py-10 animate-fade-in-up">
      <div className="bg-white/40 backdrop-blur-xl border border-white/60 shadow-xl rounded-[30px] overflow-hidden">
        {/* Header/Cover */}
        <div className="h-32 bg-gradient-to-r from-teal-500 to-cyan-500"></div>
        
        <div className="px-8 pb-8">
          <div className="relative flex justify-between items-end -mt-16 mb-6">
            <div className="flex items-end gap-6">
              <div className="w-32 h-32 rounded-[25px] border-4 border-white shadow-lg overflow-hidden bg-white">
                <img 
                  src={formData.profilePhoto || 'https://cdn-icons-png.flaticon.com/512/149/149071.png'} 
                  alt="Profile" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="mb-2">
                <h1 className="text-3xl font-extrabold text-gray-900">{user.name}</h1>
                <p className="text-teal-600 font-medium">{user.email}</p>
              </div>
            </div>
            {!isEditing && (
              <button 
                onClick={() => setIsEditing(true)}
                className="bg-white text-gray-700 border border-gray-200 px-6 py-2 rounded-full font-bold hover:bg-gray-50 transition shadow-sm"
              >
                Edit Profile
              </button>
            )}
          </div>

          {isEditing ? (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2 ml-1">Full Name</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full px-5 py-3 rounded-2xl border border-gray-200 focus:ring-2 focus:ring-teal-500 outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2 ml-1">Phone Number</label>
                  <input
                    type="text"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    className="w-full px-5 py-3 rounded-2xl border border-gray-200 focus:ring-2 focus:ring-teal-500 outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2 ml-1">Village/Town</label>
                  <input
                    type="text"
                    name="neighborhood"
                    value={formData.neighborhood}
                    onChange={handleChange}
                    className="w-full px-5 py-3 rounded-2xl border border-gray-200 focus:ring-2 focus:ring-teal-500 outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2 ml-1">Profile Photo URL</label>
                  <input
                    type="text"
                    name="profilePhoto"
                    value={formData.profilePhoto}
                    onChange={handleChange}
                    placeholder="https://example.com/photo.jpg"
                    className="w-full px-5 py-3 rounded-2xl border border-gray-200 focus:ring-2 focus:ring-teal-500 outline-none"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2 ml-1">Bio</label>
                <textarea
                  name="bio"
                  value={formData.bio}
                  onChange={handleChange}
                  rows="3"
                  className="w-full px-5 py-3 rounded-2xl border border-gray-200 focus:ring-2 focus:ring-teal-500 outline-none resize-none"
                  placeholder="Tell your neighbors about yourself..."
                ></textarea>
              </div>
              <div className="flex gap-3 pt-4">
                <button 
                  type="button" 
                  onClick={() => setIsEditing(false)}
                  className="flex-1 py-3 bg-gray-100 text-gray-700 rounded-full font-bold hover:bg-gray-200 transition"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="flex-1 py-3 bg-gradient-to-r from-teal-500 to-cyan-500 text-white rounded-full font-bold shadow-lg shadow-teal-500/20 hover:opacity-90 transition"
                >
                  Save Changes
                </button>
              </div>
            </form>
          ) : (
            <div className="space-y-8">
              <div className="bg-gray-50/50 rounded-3xl p-6 border border-gray-100">
                <h3 className="text-sm font-extrabold text-gray-400 uppercase tracking-widest mb-4">About Me</h3>
                <p className="text-gray-700 leading-relaxed italic">
                  {user.bio || "No bio yet. Click 'Edit Profile' to add one!"}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm flex flex-col items-center text-center">
                  <div className="w-12 h-12 bg-teal-50 text-teal-600 rounded-2xl flex items-center justify-center text-xl mb-4">📍</div>
                  <h4 className="text-sm font-bold text-gray-400 uppercase mb-1">Neighborhood</h4>
                  <p className="font-bold text-gray-800">{user.neighborhood}</p>
                </div>
                <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm flex flex-col items-center text-center">
                  <div className="w-12 h-12 bg-cyan-50 text-cyan-600 rounded-2xl flex items-center justify-center text-xl mb-4">📱</div>
                  <h4 className="text-sm font-bold text-gray-400 uppercase mb-1">Phone</h4>
                  <p className="font-bold text-gray-800">{user.phone || 'Not provided'}</p>
                </div>
                <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm flex flex-col items-center text-center">
                  <div className="w-12 h-12 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center text-xl mb-4">🗓️</div>
                  <h4 className="text-sm font-bold text-gray-400 uppercase mb-1">Joined</h4>
                  <p className="font-bold text-gray-800">
                    {user.createdAt ? new Date(user.createdAt).toLocaleDateString() : 'New Member'}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="bg-gradient-to-br from-teal-50 to-teal-100/50 p-8 rounded-[30px] border border-teal-100 text-center">
                  <p className="text-4xl font-black text-teal-600 mb-2">{stats.items}</p>
                  <p className="text-sm font-bold text-teal-700 uppercase tracking-wide">Items Listed</p>
                </div>
                <div className="bg-gradient-to-br from-cyan-50 to-cyan-100/50 p-8 rounded-[30px] border border-cyan-100 text-center">
                  <p className="text-4xl font-black text-cyan-600 mb-2">{stats.requests}</p>
                  <p className="text-sm font-bold text-cyan-700 uppercase tracking-wide">Total Requests</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Profile;
