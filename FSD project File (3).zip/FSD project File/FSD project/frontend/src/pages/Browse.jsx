import React, { useState, useEffect, useContext } from 'react';
import api from '../services/api';
import ItemCard from '../components/ItemCard';
import { AuthContext } from '../context/AuthContext';
import { toast } from 'react-toastify';
import { loadStripe } from '@stripe/stripe-js';
import { Elements } from '@stripe/react-stripe-js';
import CheckoutForm from '../components/CheckoutForm';

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY || 'pk_test_51MockPublicKeyForLocalDevOnly999999999999');

const Browse = () => {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [category, setCategory] = useState('');
  const [neighborhood, setNeighborhood] = useState('');
  const { user } = useContext(AuthContext);
  const [requestingItemId, setRequestingItemId] = useState(null);
  const [requestMessage, setRequestMessage] = useState('');

  useEffect(() => {
    fetchItems();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchTerm, category, neighborhood]);

  const fetchItems = async () => {
    try {
      setLoading(true);
      let url = '/items?';
      if (searchTerm) url += `search=${searchTerm}&`;
      if (category) url += `category=${category}&`;
      if (neighborhood) url += `neighborhood=${neighborhood}`;

      const { data } = await api.get(url);
      setItems(data);
    } catch (error) {
      console.error(error);
      toast.error('Failed to load items');
    } finally {
      setLoading(false);
    }
  };

  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('Cash');
  const [clientSecret, setClientSecret] = useState(null);
  const [stripeAmount, setStripeAmount] = useState(0);

  const handleInitiateRequest = (itemId) => {
    if (!user) {
      toast.info('Please log in to make a request');
      return;
    }
    setRequestingItemId(itemId);
    setRequestMessage('');
    setStartDate('');
    setEndDate('');
    setPaymentMethod('Cash');
    setClientSecret(null);
  };

  const handleCancelRequest = () => {
    setRequestingItemId(null);
    setRequestMessage('');
    setClientSecret(null);
  };

  const handleConfirmRequest = async (itemId) => {
    if (!requestMessage.trim() || !startDate || !endDate) {
      toast.error('Please fill out the message and select both dates.');
      return;
    }

    if (paymentMethod === 'Card') {
      try {
        const { data } = await api.post('/payments/create-payment-intent', {
          itemId,
          startDate,
          endDate
        });
        
        if (data.clientSecret) {
            setClientSecret(data.clientSecret);
            setStripeAmount(data.amount);
            return; // Wait for user to pay via Stripe Elements
        } else {
            // Free item or other scenario where no intent was created
            finalizeRequest(itemId);
        }
      } catch (error) {
         toast.error(error.response?.data?.message || 'Failed to initialize payment');
         return;
      }
    } else {
      finalizeRequest(itemId);
    }
  };

  const finalizeRequest = async (itemId) => {
    try {
      await api.post('/requests', {
        itemId,
        message: requestMessage,
        startDate,
        endDate,
        paymentMethod
      });
      toast.success('Rent request & checkout completed!');
      setRequestingItemId(null);
      setClientSecret(null);
      fetchItems();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to send request');
    }
  };

  return (
    <div className="animate-fade-in-up">
      <div className="mb-10 text-center max-w-2xl mx-auto">
        <h1 className="text-4xl font-extrabold text-gray-900 mb-4">Discover Resources</h1>
        <p className="text-gray-600 text-lg">Find what you need from people in your neighborhood.</p>

        <div className="mt-8 flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            placeholder="Search items..."
            className="flex-grow px-5 py-3 rounded-full border border-gray-200 shadow-sm focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none transition"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <input
            type="text"
            placeholder="Village/Town..."
            className="flex-grow px-5 py-3 rounded-full border border-gray-200 shadow-sm focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none transition"
            value={neighborhood}
            onChange={(e) => setNeighborhood(e.target.value)}
          />
          <select
            className="px-5 py-3 rounded-full border border-gray-200 shadow-sm focus:ring-2 focus:ring-teal-500 outline-none transition bg-white"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            <option value="">All Categories</option>
            <option value="Tools">Tools</option>
            <option value="Books">Books</option>
            <option value="Electronics">Electronics</option>
            <option value="Garden">Garden</option>
            <option value="Other">Other</option>
          </select>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-20">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-500"></div>
        </div>
      ) : items.length === 0 ? (
        <div className="text-center py-20 bg-white rounded-[20px] shadow-sm border border-gray-100 p-8">
          <p className="text-xl text-gray-500 font-medium">No items found matching your criteria.</p>
          <button
            onClick={() => { setSearchTerm(''); setCategory(''); setNeighborhood(''); }}
            className="mt-4 text-teal-500 font-bold hover:underline"
          >
            Clear filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
          {items.map(item => (
            <ItemCard
              key={item._id}
              item={item}
              actionButton={
                user && user._id === item.owner?._id ? (
                  <button disabled className="w-full bg-gray-100 text-gray-400 py-2.5 rounded-xl font-medium cursor-not-allowed">
                    Your Item
                  </button>
                ) : item.status === 'Borrowed' ? (
                  <button disabled className="w-full bg-[#F9FAFB] text-gray-400 py-2.5 rounded-full font-medium cursor-not-allowed border border-gray-200 text-sm">
                    Currently Unavailable
                  </button>
                ) : requestingItemId === item._id ? (
                  <div className="flex flex-col gap-3 p-3 bg-gray-50 rounded-xl border border-gray-100 mt-2">
                    <input
                      type="text"
                      className="w-full px-3 py-2 text-sm rounded-lg border border-gray-200 focus:ring-1 focus:ring-teal-500 outline-none"
                      placeholder="Add a message for the owner..."
                      value={requestMessage}
                      onChange={(e) => setRequestMessage(e.target.value)}
                    />
                    
                    {/* Compact Pricing Summary */}
                    <div className="flex gap-2 text-[10px] font-bold uppercase tracking-tight">
                        <div className="flex-1 bg-teal-50 text-teal-700 p-2 rounded-lg border border-teal-100 flex flex-col items-center">
                            <span>Daily: ${item.dailyRate || 0}</span>
                        </div>
                        <div className="flex-1 bg-amber-50 text-amber-700 p-2 rounded-lg border border-amber-100 flex flex-col items-center">
                            <span>Late: ${item.lateFeePerDay || 0}/day</span>
                        </div>
                    </div>

                    <div className="flex gap-2 text-sm">
                      <div className="flex flex-col w-1/2">
                        <label className="text-[10px] text-gray-500 font-bold uppercase mb-1">Rent From</label>
                        <input type="date" className="w-full px-2 py-1.5 rounded border border-gray-200 outline-none focus:border-teal-500" value={startDate} onChange={e => setStartDate(e.target.value)} />
                      </div>
                      <div className="flex flex-col w-1/2">
                        <label className="text-[10px] text-gray-500 font-bold uppercase mb-1">Rent To</label>
                        <input type="date" className="w-full px-2 py-1.5 rounded border border-gray-200 outline-none focus:border-teal-500" value={endDate} onChange={e => setEndDate(e.target.value)} />
                      </div>
                    </div>
                    <div className="flex flex-col">
                      <label className="text-[10px] text-gray-500 font-bold uppercase mb-1">Payment Method</label>
                      <select className="w-full px-3 py-2 text-sm rounded border border-gray-200 outline-none bg-white focus:border-teal-500" value={paymentMethod} onChange={e => setPaymentMethod(e.target.value)}>
                        <option value="Cash">Cash (Hand-to-Hand)</option>
                        <option value="Card">Credit/Debit Card</option>
                        <option value="UPI">UPI Transfer</option>
                      </select>
                    </div>

                    {/* Total Cost Preview */}
                    {startDate && endDate && (
                      <div className="bg-teal-50/50 p-2.5 rounded-lg border border-teal-100 flex justify-between items-center mt-1">
                        <span className="text-[11px] font-bold text-teal-700 uppercase">Estimated Total</span>
                        <span className="text-base font-extrabold text-teal-600">
                          {(() => {
                            const start = new Date(startDate);
                            const end = new Date(endDate);
                            const days = Math.max(1, Math.ceil((end - start) / (1000 * 60 * 60 * 24)));
                            return `$${days * (item.dailyRate || 0)}`;
                          })()}
                        </span>
                      </div>
                    )}

                    {clientSecret ? (
                      <div className="mt-4 p-4 bg-white rounded-xl border border-gray-200">
                        <Elements stripe={stripePromise} options={{ clientSecret }}>
                          <CheckoutForm 
                            clientSecret={clientSecret} 
                            amount={stripeAmount}
                            onSuccessfulPayment={() => finalizeRequest(item._id)} 
                            onCancel={handleCancelRequest}
                          />
                        </Elements>
                      </div>
                    ) : (
                      <div className="flex gap-2 mt-2">
                        <button
                          onClick={handleCancelRequest}
                          className="flex-1 bg-white text-gray-600 border border-gray-200 hover:bg-gray-50 py-2 rounded-lg font-bold text-sm transition-colors"
                        >
                          Cancel
                        </button>
                        <button
                          onClick={() => handleConfirmRequest(item._id)}
                          className="flex-[2] bg-gradient-to-r from-teal-500 to-cyan-500 text-white hover:opacity-90 py-2 rounded-lg font-bold text-sm transition-colors shadow-sm"
                        >
                          {paymentMethod === 'Card' ? 'Proceed to Payment' : 'Checkout'}
                        </button>
                      </div>
                    )}
                  </div>
                ) : (
                  <button
                    onClick={() => handleInitiateRequest(item._id)}
                    className="w-full bg-[#F9FAFB] text-teal-600 border border-teal-500/30 hover:bg-teal-50 py-2.5 rounded-full font-bold transition-all duration-300 flex items-center justify-center gap-2"
                  >
                    <span>Request to Rent</span>
                    {item.dailyRate > 0 ? (
                      <span className="bg-teal-100 text-teal-800 px-2 py-0.5 rounded text-xs">${item.dailyRate}/day</span>
                    ) : (
                      <span className="bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded text-xs">Free</span>
                    )}
                  </button>
                )
              }
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default Browse;

