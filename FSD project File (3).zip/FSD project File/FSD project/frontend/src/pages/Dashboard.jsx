import React, { useState, useEffect, useContext } from 'react';
import api from '../services/api';
import { AuthContext } from '../context/AuthContext';
import ItemCard from '../components/ItemCard';
import { toast } from 'react-toastify';

const Dashboard = () => {
  const { user } = useContext(AuthContext);
  const [myItems, setMyItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newItem, setNewItem] = useState({ title: '', description: '', category: '', imageUrl: '', neighborhood: '', dailyRate: 0, lateFeePerDay: 0 });
  const [requests, setRequests] = useState({ incoming: [], outgoing: [] });
  const [customCategory, setCustomCategory] = useState('');
  const [editingItem, setEditingItem] = useState(null);
  const { updateProfile } = useContext(AuthContext);
  const [phoneInput, setPhoneInput] = useState('');
  const [showPhoneBanner, setShowPhoneBanner] = useState(false);

  const [showFeedbackModal, setShowFeedbackModal] = useState(false);
  const [feedbackReq, setFeedbackReq] = useState(null);
  const [feedbackRating, setFeedbackRating] = useState(5);
  const [feedbackComment, setFeedbackComment] = useState('');
  const [appFeedback, setAppFeedback] = useState('');

  useEffect(() => {
    if (user && !user.phone) {
      setShowPhoneBanner(true);
    }
  }, [user]);

  useEffect(() => {
    fetchMyItems();
    fetchRequests();
    if (user && user.neighborhood) {
      setNewItem(prev => ({ ...prev, neighborhood: user.neighborhood }));
    }
  }, [user]);

  const fetchMyItems = async () => {
    try {
      const { data } = await api.get('/items/me');
      setMyItems(data);
    } catch (error) {
      console.error(error);
      toast.error('Failed to load your items');
    } finally {
      setLoading(false);
    }
  };

  const fetchRequests = async () => {
    try {
      const { data } = await api.get('/requests');
      setRequests(data);
    } catch (error) {
      console.error(error);
    }
  };

  const closeModal = () => {
    setShowAddModal(false);
    setEditingItem(null);
    setNewItem({ title: '', description: '', category: '', imageUrl: '', neighborhood: user?.neighborhood || '', dailyRate: 0, lateFeePerDay: 0 });
    setCustomCategory('');
  };

  const openEditModal = (item) => {
    setEditingItem(item);
    const standardCategories = ['Tools', 'Books', 'Electronics', 'Garden'];
    const isStandard = standardCategories.includes(item.category);

    setNewItem({
      title: item.title,
      description: item.description,
      category: isStandard ? item.category : 'Other',
      imageUrl: item.imageUrl,
      neighborhood: item.neighborhood,
      dailyRate: item.dailyRate,
      lateFeePerDay: item.lateFeePerDay
    });

    if (!isStandard) {
      setCustomCategory(item.category);
    } else {
      setCustomCategory('');
    }

    setShowAddModal(true);
  };

  const handleAddItem = async (e) => {
    e.preventDefault();
    try {
      const payload = {
        ...newItem,
        dailyRate: parseFloat(newItem.dailyRate) || 0,
        lateFeePerDay: parseFloat(newItem.lateFeePerDay) || 0
      };

      if (payload.category === 'Other') {
        if (!customCategory.trim()) {
          toast.error('Please specify a custom category text');
          return;
        }
        payload.category = customCategory.trim();
      }

      if (editingItem) {
        await api.put(`/items/${editingItem._id}`, payload);
        toast.success('Item updated successfully!');
      } else {
        await api.post('/items', payload);
        toast.success('Item listed successfully!');
      }

      closeModal();
      fetchMyItems();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to save item');
    }
  };

  const handleDeleteItem = async (id) => {
    if (window.confirm('Are you sure you want to delete this listing?')) {
      try {
        await api.delete(`/items/${id}`);
        toast.success('Item deleted');
        fetchMyItems();
      } catch (error) {
        console.error(error);
        toast.error('Failed to delete item');
      }
    }
  };

  const handleUpdatePhone = async () => {
    if (!phoneInput.trim()) {
      toast.error('Please enter a valid phone number');
      return;
    }
    const res = await updateProfile({ phone: phoneInput });
    if (res.success) {
      toast.success('Phone number saved!');
      setShowPhoneBanner(false);
    } else {
      toast.error(res.message);
    }
  };

  const openFeedbackModal = (req) => {
    setFeedbackReq(req);
    setFeedbackRating(5);
    setFeedbackComment('');
    setAppFeedback('');
    setShowFeedbackModal(true);
  };

  const closeFeedbackModal = () => {
    setShowFeedbackModal(false);
    setFeedbackReq(null);
  };

  const handleSubmitFeedback = async (e) => {
    e.preventDefault();
    if (!feedbackComment.trim()) {
      toast.error('Please provide a comment');
      return;
    }
    try {
      await api.put(`/requests/${feedbackReq._id}/feedback`, {
        feedbackRating,
        feedbackComment,
        appFeedback
      });
      toast.success('Feedback successfully submitted!');
      closeFeedbackModal();
      fetchRequests(); // Refresh to show the newly added feedback on the card
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to submit feedback');
    }
  };

  if (loading) return <div className="text-center py-20 text-gray-500">Loading your dashboard...</div>;

  return (
    <div className="animate-fade-in-up">
      {showPhoneBanner && (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 mb-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <h3 className="font-bold text-amber-800">Add a Contact Number</h3>
            <p className="text-sm text-amber-700">Renters and owners need to communicate to coordinate handoffs.</p>
          </div>
          <div className="flex gap-2 w-full sm:w-auto">
            <input type="tel" placeholder="e.g. 555-1234" value={phoneInput} onChange={e => setPhoneInput(e.target.value)} className="px-3 py-2 text-sm border border-amber-200 rounded-lg outline-none focus:ring-2 focus:ring-amber-500 w-full sm:w-48" />
            <button onClick={handleUpdatePhone} className="bg-amber-500 hover:bg-amber-600 text-white font-bold py-2 px-4 rounded-lg transition text-sm whitespace-nowrap">Save Phone</button>
          </div>
        </div>
      )}

      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-extrabold text-gray-900">My Dashboard</h1>
          <p className="text-gray-500 mt-1">Manage your shared resources</p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="bg-gradient-to-br from-teal-500 to-cyan-500 hover:opacity-90 text-white font-bold py-2.5 px-6 rounded-full shadow-md hover:shadow-lg hover:shadow-teal-500/20 transition-all transform hover:-translate-y-0.5"
        >
          + List New Item
        </button>
      </div>

      {myItems.length === 0 ? (
        <div className="glassmorphism rounded-3xl p-12 text-center border border-dashed border-gray-300">
          <p className="text-gray-500 text-lg mb-4">You haven't listed any items yet.</p>
          <button
            onClick={() => setShowAddModal(true)}
            className="text-teal-500 hover:opacity-80 font-semibold underline underline-offset-4"
          >
            Create your first listing
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {myItems.map(item => (
            <ItemCard
              key={item._id}
              item={item}
              actionButton={
                <div className="flex gap-2 w-full">
                  <button
                    onClick={() => openEditModal(item)}
                    className="flex-1 bg-teal-50 text-teal-600 font-medium py-2 rounded-full hover:bg-teal-100 transition duration-300 border border-teal-100"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDeleteItem(item._id)}
                    className="flex-1 bg-[#FEE2E2] text-[#DC2626] font-medium py-2 rounded-full hover:bg-red-200 transition duration-300"
                  >
                    Delete
                  </button>
                </div>
              }
            />
          ))}
        </div>
      )}

      {/* RENTALS & REQUESTS SECTION */}
      <div className="mt-16">
        <h2 className="text-3xl font-extrabold text-gray-900 mb-6">My Rentals &amp; Requests</h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">

          {/* Outgoing Requests (Items I am Renting) */}
          <div>
            <h3 className="text-xl font-bold text-teal-600 mb-4 border-b border-teal-100 pb-2">Items I am Renting</h3>
            {requests.outgoing.length === 0 ? (
              <p className="text-gray-500 italic">You have no active outgoing rent requests.</p>
            ) : (
              <div className="space-y-4">
                {requests.outgoing.map(req => (
                  <div key={req._id} className="bg-white border text-sm border-gray-200 rounded-xl p-4 shadow-sm relative">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-bold text-gray-800 text-base">{req.item?.title || 'Unknown Item'}</h4>
                      <span className={`px-2 py-1 rounded text-xs font-bold ${req.status === 'Approved' ? 'bg-teal-100 text-teal-700' : req.status === 'Returned' ? 'bg-gray-100 text-gray-700' : req.status === 'Declined' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'}`}>
                        {req.status}
                      </span>
                    </div>
                    <p className="text-gray-500 mb-1">Owner: {req.owner?.name}</p>
                    <p className="text-gray-500 mb-2">Dates: {req.startDate ? new Date(req.startDate).toLocaleDateString() : 'N/A'} &mdash; {req.endDate ? new Date(req.endDate).toLocaleDateString() : 'N/A'}</p>

                    <div className="bg-gray-50 p-2 border border-gray-100 rounded-lg flex justify-between items-center mb-2">
                      <span className="font-bold text-gray-600 uppercase text-[10px]">Payment: {req.paymentMethod || 'N/A'}</span>
                      <span className="font-bold text-teal-600">${req.totalCost || 0}</span>
                    </div>

                    {req.status === 'Approved' && (
                      <div className="bg-blue-50 border border-blue-100 p-2 rounded-lg mb-2 text-sm">
                        <span className="font-bold text-blue-700 block mb-1">Contact Owner:</span>
                        <a href={`tel:${req.owner?.phone || ''}`} className="text-blue-600 font-medium underline">{req.owner?.phone || 'No phone provided'}</a>
                      </div>
                    )}

                    {req.lateFeeIncurred > 0 && <p className="text-red-500 text-xs font-bold w-full text-right mb-2">Late Fees: ${req.lateFeeIncurred}</p>}

                    {req.status === 'Returned' && !req.feedbackRating && (
                      <button onClick={() => openFeedbackModal(req)} className="w-full bg-amber-500 hover:bg-amber-600 text-white font-bold py-1.5 rounded-lg transition mt-2 shadow-sm text-sm">
                        Leave Feedback
                      </button>
                    )}

                    {req.feedbackRating && (
                      <div className="bg-amber-50 border border-amber-100 p-3 rounded-lg mt-3 text-sm">
                        <span className="font-bold text-amber-800 block mb-1">Your Rating: {"★".repeat(req.feedbackRating)}{"☆".repeat(5 - req.feedbackRating)}</span>
                        <p className="text-amber-900 italic mb-2">"{req.feedbackComment}"</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Incoming Requests (People Renting from Me) */}
          <div>
            <h3 className="text-xl font-bold text-[#C084FC] mb-4 border-b border-[#C084FC]/20 pb-2">Incoming Rent Requests</h3>
            {requests.incoming.length === 0 ? (
              <p className="text-gray-500 italic">No one is currently renting your items.</p>
            ) : (
              <div className="space-y-4">
                {requests.incoming.map(req => (
                  <div key={req._id} className="bg-white border text-sm border-gray-200 rounded-xl p-4 shadow-sm relative">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-bold text-gray-800 text-base">{req.item?.title || 'Unknown Item'}</h4>
                      <span className={`px-2 py-1 rounded text-xs font-bold ${req.status === 'Approved' ? 'bg-teal-100 text-teal-700' : req.status === 'Returned' ? 'bg-gray-100 text-gray-700' : req.status === 'Declined' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'}`}>
                        {req.status}
                      </span>
                    </div>
                    <p className="text-gray-500 mb-1">Renter: {req.requester?.name}</p>
                    <p className="text-gray-500 mb-2">Message: "{req.message || 'No message'}"</p>
                    <p className="text-gray-500 mb-2">Dates: {req.startDate ? new Date(req.startDate).toLocaleDateString() : 'N/A'} &mdash; {req.endDate ? new Date(req.endDate).toLocaleDateString() : 'N/A'}</p>

                    <div className="bg-gray-50 p-2 border border-gray-100 rounded-lg flex justify-between items-center mb-3">
                      <span className="font-bold text-gray-600 uppercase text-[10px]">Payment: {req.paymentMethod || 'N/A'}</span>
                      <span className="font-bold text-teal-600">Expected: ${req.totalCost || 0}</span>
                    </div>

                    {req.status === 'Approved' && (
                      <div className="bg-blue-50 border border-blue-100 p-2 rounded-lg mb-3 text-sm">
                        <span className="font-bold text-blue-700 block mb-1">Contact Renter:</span>
                        <a href={`tel:${req.requester?.phone || ''}`} className="text-blue-600 font-medium underline">{req.requester?.phone || 'No phone provided'}</a>
                      </div>
                    )}

                    {req.lateFeeIncurred > 0 && <p className="text-red-500 text-xs font-bold mb-2">Late Fees Collected: ${req.lateFeeIncurred}</p>}

                    {req.status === 'Pending' && (
                      <div className="flex gap-2">
                        <button onClick={async () => { await api.put(`/requests/${req._id}`, { status: 'Approved' }); fetchRequests(); fetchMyItems(); }} className="flex-1 bg-teal-500 hover:bg-teal-600 text-white font-bold py-1.5 rounded-lg transition">Approve</button>
                        <button onClick={async () => { await api.put(`/requests/${req._id}`, { status: 'Declined' }); fetchRequests(); fetchMyItems(); }} className="flex-1 bg-red-500 hover:bg-red-600 text-white font-bold py-1.5 rounded-lg transition">Decline</button>
                      </div>
                    )}
                    {req.status === 'Approved' && (
                      <button onClick={async () => { await api.put(`/requests/${req._id}`, { status: 'Returned' }); fetchRequests(); fetchMyItems(); }} className="w-full bg-gray-800 hover:bg-black text-white font-bold py-1.5 rounded-lg transition">Mark as Returned</button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Add/Edit Item Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-[20px] p-8 w-full max-w-md shadow-2xl animate-fade-in-up">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">{editingItem ? 'Edit Item' : 'List an Item'}</h2>
            <form onSubmit={handleAddItem} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
                <input
                  type="text" required
                  className="w-full px-4 py-2 border rounded-full focus:ring-2 focus:ring-teal-500 outline-none"
                  value={newItem.title} onChange={e => setNewItem({ ...newItem, title: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                <select
                  required={newItem.category !== 'Other'}
                  className="w-full px-4 py-2 border rounded-full focus:ring-2 focus:ring-teal-500 outline-none"
                  value={newItem.category} onChange={e => setNewItem({ ...newItem, category: e.target.value })}
                >
                  <option value="">Select a category...</option>
                  <option value="Tools">Tools</option>
                  <option value="Books">Books</option>
                  <option value="Electronics">Electronics</option>
                  <option value="Garden">Garden</option>
                  <option value="Other">Other (Type below)</option>
                </select>
                {newItem.category === 'Other' && (
                  <input
                    type="text"
                    placeholder="Specify your category..."
                    className="w-full px-4 py-2 mt-2 border border-teal-200 rounded-full focus:ring-2 focus:ring-teal-500 outline-none animate-fade-in-up"
                    value={customCategory}
                    onChange={e => setCustomCategory(e.target.value)}
                    required
                  />
                )}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea
                  required rows="3"
                  className="w-full px-4 py-2 border rounded-[20px] focus:ring-2 focus:ring-teal-500 outline-none"
                  value={newItem.description} onChange={e => setNewItem({ ...newItem, description: e.target.value })}
                ></textarea>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Image URL (Optional)</label>
                <input
                  type="url"
                  className="w-full px-4 py-2 border rounded-full focus:ring-2 focus:ring-teal-500 outline-none"
                  value={newItem.imageUrl} onChange={e => setNewItem({ ...newItem, imageUrl: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Village/Town (Location)</label>
                <input
                  type="text" required
                  className="w-full px-4 py-2 border rounded-full focus:ring-2 focus:ring-teal-500 outline-none"
                  value={newItem.neighborhood} onChange={e => setNewItem({ ...newItem, neighborhood: e.target.value })}
                />
              </div>
              <div className="flex gap-4">
                <div className="flex-1">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Daily Rent Price</label>
                  <input
                    type="number" min="0" required
                    className="w-full px-4 py-2 border rounded-full focus:ring-2 focus:ring-teal-500 outline-none"
                    value={newItem.dailyRate} onChange={e => setNewItem({ ...newItem, dailyRate: e.target.value })}
                  />
                </div>
                <div className="flex-1">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Late Return Fee/Day</label>
                  <input
                    type="number" min="0" required
                    className="w-full px-4 py-2 border rounded-full focus:ring-2 focus:ring-teal-500 outline-none"
                    value={newItem.lateFeePerDay} onChange={e => setNewItem({ ...newItem, lateFeePerDay: e.target.value })}
                  />
                </div>
              </div>
              <div className="flex gap-3 pt-4">
                <button type="button" onClick={closeModal} className="flex-1 py-3 text-gray-900 bg-gray-100 hover:bg-gray-200 rounded-full font-medium transition">Cancel</button>
                <button type="submit" className="flex-1 py-3 bg-gradient-to-br from-teal-500 to-cyan-500 hover:opacity-90 text-white rounded-full font-medium transition shadow-md hover:shadow-lg hover:shadow-teal-500/20">
                  {editingItem ? 'Save Changes' : 'List Item'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* FEEDBACK MODAL */}
      {showFeedbackModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-8 w-full max-w-md shadow-2xl animate-fade-in-up">
            <h2 className="text-2xl font-extrabold text-gray-900 mb-2">Leave Feedback</h2>
            <p className="text-gray-500 mb-6 text-sm">Rate your experience renting <strong>{feedbackReq?.item?.title}</strong> from <strong>{feedbackReq?.owner?.name}</strong>.</p>
            
            <form onSubmit={handleSubmitFeedback}>
              <div className="mb-6">
                <label className="block text-sm font-bold text-gray-700 mb-2">Rating</label>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setFeedbackRating(star)}
                      className={`text-3xl transition-transform hover:scale-110 ${feedbackRating >= star ? 'text-amber-400' : 'text-gray-200'}`}
                    >
                      ★
                    </button>
                  ))}
                </div>
              </div>

              <div className="mb-6">
                <label className="block text-sm font-bold text-gray-700 mb-2">Item/Owner Comment</label>
                <textarea
                  required
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-amber-500 outline-none resize-none h-20"
                  placeholder="How was the item? Was the owner communicative?"
                  value={feedbackComment}
                  onChange={(e) => setFeedbackComment(e.target.value)}
                ></textarea>
              </div>

              <div className="mb-8">
                <label className="block text-sm font-bold text-gray-700 mb-2">App Feedback <span className="text-gray-400 font-normal">(Optional)</span></label>
                <textarea
                  className="w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-amber-500 outline-none resize-none h-20 text-sm"
                  placeholder="How can we improve NeighborNet for you?"
                  value={appFeedback}
                  onChange={(e) => setAppFeedback(e.target.value)}
                ></textarea>
              </div>

              <div className="flex gap-3">
                <button type="button" onClick={closeFeedbackModal} className="flex-1 px-4 py-3 border border-gray-200 text-gray-700 rounded-xl font-bold hover:bg-gray-50 transition">Cancel</button>
                <button type="submit" className="flex-1 px-4 py-3 bg-amber-500 text-white rounded-xl font-bold hover:bg-amber-600 transition shadow-lg shadow-amber-500/30">Submit</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;

