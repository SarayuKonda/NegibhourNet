async function testCheckout() {
    try {
        console.log('Logging in to test account...');
        let loginRes = await fetch('http://localhost:5000/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: 'test@example.com', password: 'password123' })
        });
        
        let loginData = await loginRes.json();
        
        if (!loginRes.ok) {
            console.log('Login failed, registering test user...');
            loginRes = await fetch('http://localhost:5000/api/auth/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    name: 'Test User',
                    email: 'test@example.com',
                    password: 'password123',
                    neighborhood: 'Testville'
                })
            });
            loginData = await loginRes.json();
        }
        
        const token = loginData.token;
        console.log('Got token:', token.substring(0, 10) + '...');

        console.log('Fetching items...');
        const itemsRes = await fetch('http://localhost:5000/api/items');
        const items = await itemsRes.json();
        if (items.length === 0) { console.log('No items to request'); return; }
        
        let targetItem = null;
        for (const item of items) {
           if (item.owner._id !== loginData._id && item.status === 'Available') {
               targetItem = item;
               break;
           }
        }

        if (!targetItem) {
            console.log('No available item not owned by me found.');
            return;
        }

        console.log(`Checking out Item ID: ${targetItem._id}`);

        const payload = {
            itemId: targetItem._id,
            message: "I would like to rent this",
            startDate: "2026-04-12",
            endDate: "2026-04-14",
            paymentMethod: "Cash"
        };
        console.log('Sending Payload:', payload);

        const checkoutRes = await fetch('http://localhost:5000/api/requests', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}` 
            },
            body: JSON.stringify(payload)
        });

        const checkoutData = await checkoutRes.json();
        
        if (checkoutRes.ok) {
            console.log('Checkout Success:', checkoutData);
        } else {
            console.error('Checkout Failed. Status:', checkoutRes.status);
            console.error('Error Message:', checkoutData);
        }

    } catch (error) {
        console.error('Network Error:', error);
    }
}

testCheckout();
