const express = require('express');
const router = express.Router();
const {
    createRequest,
    getMyRequests,
    updateRequestStatus,
    addFeedback,
} = require('../controllers/requestController');
const { protect } = require('../middleware/authMiddleware');

router.route('/').post(protect, createRequest).get(protect, getMyRequests);
router.route('/:id').put(protect, updateRequestStatus);
router.route('/:id/feedback').put(protect, addFeedback);

module.exports = router;
