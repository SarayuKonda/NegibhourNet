const mongoose = require('mongoose');
const dotenv = require('dotenv');
const path = require('path');
const Item = require('./models/Item');

dotenv.config({ path: path.join(__dirname, '.env') });

const checkItems = async () => {
    try {
        await mongoose.connect(process.env.MONGODB_URI);
        console.log('Connected to MongoDB');

        const items = await Item.find({});
        console.log(`Found ${items.length} items:`);
        items.forEach(item => {
            console.log(`Item: ${item.title}, Price: ${item.dailyRate}, Metadata: ${JSON.stringify({ dailyRate: item.dailyRate, lateFee: item.lateFeePerDay })}`);
        });

        await mongoose.disconnect();
    } catch (error) {
        console.error('Error:', error);
    }
};

checkItems();
