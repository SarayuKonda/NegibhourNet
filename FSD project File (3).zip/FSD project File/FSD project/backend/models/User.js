const mongoose = require('mongoose');

const userSchema = mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Please add a name'],
    },
    email: {
        type: String,
        required: [true, 'Please add an email'],
        unique: true,
    },
    password: {
        type: String,
        required: [true, 'Please add a password'],
    },
    neighborhood: {
        type: String,
        required: [true, 'Please add a neighborhood'],
    },
    phone: {
        type: String,
        default: '',
    },
    profilePhoto: {
        type: String,
        default: 'https://cdn-icons-png.flaticon.com/512/149/149071.png',
    },
    bio: {
        type: String,
        default: '',
    }
}, {
    timestamps: true,
});

module.exports = mongoose.model('User', userSchema);
