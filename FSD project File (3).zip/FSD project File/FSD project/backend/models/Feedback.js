const mongoose = require('mongoose');

const feedbackSchema = mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'User',
    },
    message: {
        type: String,
        required: true,
    }
}, {
    timestamps: true,
    collection: 'feedbacks'
});

module.exports = mongoose.model('Feedback', feedbackSchema);
