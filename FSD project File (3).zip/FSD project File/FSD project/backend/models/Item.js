const mongoose = require('mongoose');

const itemSchema = mongoose.Schema({
    owner: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'User',
    },
    title: {
        type: String,
        required: [true, 'Please add a title'],
    },
    description: {
        type: String,
        required: [true, 'Please add a description'],
    },
    category: {
        type: String,
        required: [true, 'Please add a category (e.g., Tools, Books)'],
    },
    neighborhood: {
        type: String,
        required: [true, 'Please add a neighborhood (village/town)'],
    },
    status: {
        type: String,
        enum: ['Available', 'Borrowed'],
        default: 'Available',
    },
    dailyRate: {
        type: Number,
        default: 0,
    },
    lateFeePerDay: {
        type: Number,
        default: 0,
    },
    imageUrl: {
        type: String,
        default: 'https://via.placeholder.com/400x300?text=No+Image',
    },
    rating: {
        type: Number,
        default: 0,
    },
    numReviews: {
        type: Number,
        default: 0,
    }
}, {
    timestamps: true,
});

module.exports = mongoose.model('Item', itemSchema);
