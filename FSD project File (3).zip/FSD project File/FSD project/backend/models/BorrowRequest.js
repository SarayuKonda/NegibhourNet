const mongoose = require('mongoose');

const borrowRequestSchema = mongoose.Schema({
    item: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'Item',
    },
    requester: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'User',
    },
    owner: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'User',
    },
    status: {
        type: String,
        enum: ['Pending', 'Approved', 'Declined', 'Returned'],
        default: 'Pending',
    },
    message: {
        type: String,
        required: [true, 'Please add a message to the owner'],
    },
    startDate: {
        type: Date,
        required: true,
    },
    endDate: {
        type: Date,
        required: true,
    },
    paymentMethod: {
        type: String,
        enum: ['Cash', 'Card', 'UPI'],
        required: true,
    },
    totalCost: {
        type: Number,
        required: true,
        default: 0,
    },
    lateFeeIncurred: {
        type: Number,
        default: 0,
    },
    feedbackRating: {
        type: Number,
        min: 1,
        max: 5,
    },
    feedbackComment: {
        type: String,
    }
}, {
    timestamps: true,
});

module.exports = mongoose.model('BorrowRequest', borrowRequestSchema);
