const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY || 'sk_test_51MockSecretKeyForLocalDevOnly999999999999');
const Item = require('../models/Item');

// @desc    Create Stripe Payment Intent
// @route   POST /api/payments/create-payment-intent
// @access  Private
const createPaymentIntent = async (req, res, next) => {
    try {
        const { itemId, startDate, endDate } = req.body;

        if (!itemId || !startDate || !endDate) {
            res.status(400);
            return next(new Error('Please provide item ID, start date, and end date'));
        }

        const item = await Item.findById(itemId);
        if (!item) {
            res.status(404);
            return next(new Error('Item not found'));
        }

        const start = new Date(startDate);
        const end = new Date(endDate);
        if (start > end) {
            res.status(400);
            return next(new Error('Start date must be before end date'));
        }

        const msPerDay = 1000 * 60 * 60 * 24;
        const days = Math.ceil((end - start) / msPerDay) || 1;
        const itemPrice = item.dailyRate || 0;
        
        // Total cost in dollars
        const totalCost = days * itemPrice;

        // Stripe requires amount in smallest currency unit (cents)
        const amountInCents = Math.round(totalCost * 100);

        // If amount is 0, we shouldn't create a payment intent (it's free)
        if (amountInCents === 0) {
            return res.json({
                clientSecret: null,
                message: 'Item is free, no payment required.'
            });
        }

        // Create a PaymentIntent with the order amount and currency
        const paymentIntent = await stripe.paymentIntents.create({
            amount: amountInCents,
            currency: 'usd',
            // In the latest version of the API, specifying the `automatic_payment_methods` parameter is optional because Stripe enables its functionality by default.
            automatic_payment_methods: {
                enabled: true,
            },
            metadata: {
                itemId: item._id.toString(),
                userId: req.user.id.toString(),
            }
        });

        res.json({
            clientSecret: paymentIntent.client_secret,
            amount: totalCost
        });
    } catch (error) {
        console.error("Stripe Error: ", error);
        next(error);
    }
};

module.exports = {
    createPaymentIntent
};
