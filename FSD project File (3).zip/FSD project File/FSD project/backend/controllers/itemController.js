const Item = require('../models/Item');

// @desc    Get all items (browse)
// @route   GET /api/items
// @access  Public
const getItems = async (req, res, next) => {
    try {
        // Can add filters like req.query.category etc.
        const filter = {};
        if (req.query.search) {
            filter.title = { $regex: req.query.search, $options: 'i' };
        }
        if (req.query.category) {
            filter.category = req.query.category;
        }
        if (req.query.neighborhood) {
            filter.neighborhood = { $regex: req.query.neighborhood, $options: 'i' };
        }

        const items = await Item.find(filter).populate('owner', 'name neighborhood');
        res.status(200).json(items);
    } catch (error) {
        next(error);
    }
};

// @desc    Get user's items
// @route   GET /api/items/me
// @access  Private
const getMyItems = async (req, res, next) => {
    try {
        const items = await Item.find({ owner: req.user.id });
        res.status(200).json(items);
    } catch (error) {
        next(error);
    }
};

// @desc    Get single item
// @route   GET /api/items/:id
// @access  Public
const getItemById = async (req, res, next) => {
    try {
        const item = await Item.findById(req.params.id).populate('owner', 'name neighborhood');
        if (!item) {
            res.status(404);
            return next(new Error('Item not found'));
        }
        res.status(200).json(item);
    } catch (error) {
        next(error);
    }
};

// @desc    Create new item listing
// @route   POST /api/items
// @access  Private
const createItem = async (req, res, next) => {
    try {
        const { title, description, category, imageUrl, neighborhood, dailyRate, lateFeePerDay } = req.body;

        if (!title || !description || !category || !neighborhood) {
            res.status(400);
            return next(new Error('Please add all required fields'));
        }

        const item = await Item.create({
            title,
            description,
            category,
            imageUrl,
            neighborhood,
            dailyRate: dailyRate || 0,
            lateFeePerDay: lateFeePerDay || 0,
            owner: req.user.id,
        });

        res.status(201).json(item);
    } catch (error) {
        next(error);
    }
};

// @desc    Update item
// @route   PUT /api/items/:id
// @access  Private
const updateItem = async (req, res, next) => {
    try {
        const item = await Item.findById(req.params.id);

        if (!item) {
            res.status(404);
            return next(new Error('Item not found'));
        }

        // Check for user
        if (!req.user) {
            res.status(401);
            return next(new Error('User not found'));
        }

        // Make sure the logged in user matches the item owner
        if (item.owner.toString() !== req.user.id) {
            res.status(401);
            return next(new Error('User not authorized'));
        }

        const { title, description, category, imageUrl, neighborhood, dailyRate, lateFeePerDay } = req.body;

        const updateData = {
            title,
            description,
            category,
            imageUrl,
            neighborhood,
            dailyRate: dailyRate !== undefined ? Number(dailyRate) : item.dailyRate,
            lateFeePerDay: lateFeePerDay !== undefined ? Number(lateFeePerDay) : item.lateFeePerDay
        };

        const updatedItem = await Item.findByIdAndUpdate(req.params.id, updateData, {
            new: true,
            runValidators: true
        });

        res.status(200).json(updatedItem);
    } catch (error) {
        next(error);
    }
};

// @desc    Delete item
// @route   DELETE /api/items/:id
// @access  Private
const deleteItem = async (req, res, next) => {
    try {
        const item = await Item.findById(req.params.id);

        if (!item) {
            res.status(404);
            return next(new Error('Item not found'));
        }

        // Make sure the logged in user matches the item owner
        if (item.owner.toString() !== req.user.id) {
            res.status(401);
            return next(new Error('User not authorized'));
        }

        await item.deleteOne();

        res.status(200).json({ id: req.params.id });
    } catch (error) {
        next(error);
    }
};

module.exports = {
    getItems,
    getMyItems,
    getItemById,
    createItem,
    updateItem,
    deleteItem,
};
