const Message = require('../models/Message');

// @desc    Send a message
// @route   POST /api/messages
// @access  Private
const sendMessage = async (req, res, next) => {
    try {
        const { receiverId, itemId, content } = req.body;

        if (!receiverId || !content) {
            res.status(400);
            return next(new Error('Please provide receiver and content'));
        }

        const message = await Message.create({
            sender: req.user.id,
            receiver: receiverId,
            item: itemId || null,
            content,
        });

        res.status(201).json(message);
    } catch (error) {
        next(error);
    }
};

// @desc    Get messages with a specific user
// @route   GET /api/messages/:userId
// @access  Private
const getMessages = async (req, res, next) => {
    try {
        const otherUserId = req.params.userId;

        const messages = await Message.find({
            $or: [
                { sender: req.user.id, receiver: otherUserId },
                { sender: otherUserId, receiver: req.user.id },
            ],
        }).sort({ createdAt: 1 })
          .populate('sender', 'name')
          .populate('receiver', 'name');

        res.status(200).json(messages);
    } catch (error) {
        next(error);
    }
};

// @desc    Get all conversations map (latest message per user)
// @route   GET /api/messages/conversations/me
// @access  Private
const getConversations = async (req, res, next) => {
    try {
        const userId = req.user.id;
        
        // Find all messages involving the user
        const messages = await Message.find({
            $or: [{ sender: userId }, { receiver: userId }]
        }).sort({ createdAt: -1 })
          .populate('sender', 'name email')
          .populate('receiver', 'name email');

        // Extract unique users
        const map = new Map();

        messages.forEach(msg => {
            const partnerId = msg.sender._id.toString() === userId.toString() ? msg.receiver._id.toString() : msg.sender._id.toString();
            const partner = msg.sender._id.toString() === userId.toString() ? msg.receiver : msg.sender;

            if (!map.has(partnerId)) {
                map.set(partnerId, {
                    partner,
                    latestMessage: msg,
                });
            }
        });

        res.status(200).json(Array.from(map.values()));
    } catch (error) {
        next(error);
    }
}

module.exports = {
    sendMessage,
    getMessages,
    getConversations
};
