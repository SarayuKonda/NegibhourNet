const BorrowRequest = require('../models/BorrowRequest');
const Item = require('../models/Item');

// @desc    Create a borrow request
// @route   POST /api/requests
// @access  Private
const createRequest = async (req, res, next) => {
    try {
        const { itemId, message, startDate, endDate, paymentMethod } = req.body;

        if (!itemId || !message || !startDate || !endDate || !paymentMethod) {
            res.status(400);
            return next(new Error('Please provide item ID, message, start date, end date, and payment method'));
        }

        const item = await Item.findById(itemId);

        if (!item) {
            res.status(404);
            return next(new Error('Item not found'));
        }

        if (item.owner.toString() === req.user.id) {
            res.status(400);
            return next(new Error('You cannot request your own item'));
        }

        const start = new Date(startDate);
        const end = new Date(endDate);
        if (start > end) {
            res.status(400);
            return next(new Error('Start date must be before end date'));
        }

        // Calculate Total Cost
        const msPerDay = 1000 * 60 * 60 * 24;
        const days = Math.ceil((end - start) / msPerDay) || 1; // Minimum 1 day
        const itemPrice = item.dailyRate || 0;
        const totalCost = days * itemPrice;

        // Check if already requested by this user pending
        const existingRequest = await BorrowRequest.findOne({
            item: itemId,
            requester: req.user.id,
            status: { $in: ['Pending', 'Approved'] }
        });

        if (existingRequest) {
            res.status(400);
            return next(new Error('You already have an active request for this item'));
        }

        const request = await BorrowRequest.create({
            item: itemId,
            requester: req.user.id,
            owner: item.owner,
            message,
            startDate,
            endDate,
            paymentMethod,
            totalCost
        });

        // Item stays 'Available' until the owner approves a request.
        // Multiple users can request the same item — the owner picks one.

        res.status(201).json(request);
    } catch (error) {
        next(error);
    }
};

// @desc    Get user's incoming & outgoing requests
// @route   GET /api/requests
// @access  Private
const getMyRequests = async (req, res, next) => {
    try {
        const outgoing = await BorrowRequest.find({ requester: req.user.id })
            .populate('item', 'title imageUrl status')
            .populate('owner', 'name email neighborhood phone');

        const incoming = await BorrowRequest.find({ owner: req.user.id })
            .populate('item', 'title imageUrl status')
            .populate('requester', 'name email neighborhood phone');

        res.status(200).json({ outgoing, incoming });
    } catch (error) {
        next(error);
    }
};

// @desc    Update request status (Approve, Decline, Returned)
// @route   PUT /api/requests/:id
// @access  Private
const updateRequestStatus = async (req, res, next) => {
    try {
        const { status } = req.body;
        const request = await BorrowRequest.findById(req.params.id);

        if (!request) {
            res.status(404);
            return next(new Error('Request not found'));
        }

        const item = await Item.findById(request.item);

        // Only the owner can approve/decline
        // Both can mark returned? For simplicity, let's say only owner marks as returned.
        if (request.owner.toString() !== req.user.id && request.requester.toString() !== req.user.id) {
            res.status(401);
            return next(new Error('Not authorized to update this request'));
        }

        // Let's keep it simple: owner manages the lifecycle
        if (request.owner.toString() !== req.user.id && ['Approved', 'Declined'].includes(status)) {
            res.status(401);
            return next(new Error('Only owner can approve or decline'));
        }

        if (status === 'Returned') {
            const now = new Date();
            const endDate = new Date(request.endDate);
            if (now > endDate && item.lateFeePerDay > 0) {
                const msPerDay = 1000 * 60 * 60 * 24;
                const lateDays = Math.ceil((now - endDate) / msPerDay);
                request.lateFeeIncurred = lateDays * item.lateFeePerDay;
            }
            item.status = 'Available';
        } else if (status === 'Approved') {
            item.status = 'Borrowed';

            // Auto-decline all other pending requests for this item
            await BorrowRequest.updateMany(
                {
                    item: request.item,
                    _id: { $ne: request._id },
                    status: 'Pending'
                },
                { status: 'Declined' }
            );
        } else if (status === 'Declined') {
            // Only revert to Available if no other approved/pending requests exist
            const otherActive = await BorrowRequest.findOne({
                item: request.item,
                _id: { $ne: request._id },
                status: { $in: ['Pending', 'Approved'] }
            });
            if (!otherActive) {
                item.status = 'Available';
            }
        }

        request.status = status;
        const updatedRequest = await request.save();
        await item.save();

        res.status(200).json(updatedRequest);
    } catch (error) {
        next(error);
    }
};

const Feedback = require('../models/Feedback');
const fs = require('fs');
const path = require('path');

// @desc    Add feedback to a returned request
// @route   PUT /api/requests/:id/feedback
// @access  Private
const addFeedback = async (req, res, next) => {
    try {
        const { feedbackRating, feedbackComment, appFeedback } = req.body;
        const request = await BorrowRequest.findById(req.params.id);

        if (!request) {
            res.status(404);
            return next(new Error('Request not found'));
        }

        // Only the requester can leave feedback
        if (request.requester.toString() !== req.user.id) {
            res.status(401);
            return next(new Error('Only the renter can leave feedback on this transaction'));
        }

        // Must be in Returned status
        if (request.status !== 'Returned') {
            res.status(400);
            return next(new Error('Feedback can only be provided after the item is returned'));
        }

        request.feedbackRating = Number(feedbackRating);
        request.feedbackComment = feedbackComment;
        
        // Handle App Feedback explicitly decoupling it from the request model
        if (appFeedback && appFeedback.trim().length > 0) {
            // Save to DB
            await Feedback.create({
                user: req.user.id,
                message: appFeedback.trim()
            });

            // Write to local folder for easy admin reading
            const feedbackDir = path.join(__dirname, '..', 'app_feedbacks');
            if (!fs.existsSync(feedbackDir)) {
                fs.mkdirSync(feedbackDir);
            }
            const logName = `feedback_${Date.now()}.txt`;
            fs.writeFileSync(path.join(feedbackDir, logName), `From User ID: ${req.user.id}\nDate: ${new Date().toISOString()}\nFeedback: ${appFeedback.trim()}\n`);
        }
        
        const updatedRequest = await request.save();

        // Recalculate Item Rating
        try {
            const item = await Item.findById(request.item);
            if (item) {
                const totalRatingCount = item.numReviews || 0;
                const currentRating = item.rating || 0;
                
                const newRatingCount = totalRatingCount + 1;
                // Running average calculation
                const newRating = ((currentRating * totalRatingCount) + Number(feedbackRating)) / newRatingCount;
                
                item.rating = newRating;
                item.numReviews = newRatingCount;
                await item.save();
            }
        } catch (itemErr) {
            console.error('Failed to update item rating', itemErr);
        }

        res.status(200).json(updatedRequest);
    } catch (error) {
        next(error);
    }
};

module.exports = {
    createRequest,
    getMyRequests,
    updateRequestStatus,
    addFeedback,
};
