const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const User = require('../models/User');

// Generate JWT
const generateToken = (id) => {
    return jwt.sign({ id }, process.env.JWT_SECRET, {
        expiresIn: '30d',
    });
};

// @desc    Register new user
// @route   POST /api/auth/register
// @access  Public
const registerUser = async (req, res, next) => {
    try {
        const { name, email, password, neighborhood, phone } = req.body;

        if (!name || !email || !password || !neighborhood) {
            res.status(400);
            return next(new Error('Please add all required fields'));
        }

        // Validate email format
        const emailRegex = /^[a-zA-Z0-9._%+-]+@(gmail\.com|yahoo\.com|outlook\.com|hotmail\.com|icloud\.com|protonmail\.com|zoho\.com|aol\.com|mail\.ru|yandex\.com)$/i;
        if (!emailRegex.test(email)) {
            res.status(400);
            return next(new Error('Please enter a valid email address (e.g. user@gmail.com)'));
        }

        // Validate phone number (must be exactly 10 digits)
        if (phone) {
            const cleanPhone = phone.replace(/[\s\-\(\)]/g, '');
            if (!/^\d{10}$/.test(cleanPhone)) {
                res.status(400);
                return next(new Error('Phone number must be exactly 10 digits'));
            }
        }

        // Validate password strength
        if (password.length < 6) {
            res.status(400);
            return next(new Error('Password must be at least 6 characters'));
        }

        const userExists = await User.findOne({ email });

        if (userExists) {
            res.status(400);
            return next(new Error('User already exists'));
        }

        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        const user = await User.create({
            name,
            email,
            password: hashedPassword,
            neighborhood,
            phone: phone || '',
        });

        if (user) {
            res.status(201).json({
                _id: user.id,
                name: user.name,
                email: user.email,
                neighborhood: user.neighborhood,
                phone: user.phone,
                profilePhoto: user.profilePhoto,
                bio: user.bio,
                token: generateToken(user._id),
            });
        } else {
            res.status(400);
            return next(new Error('Invalid user data'));
        }
    } catch (error) {
        next(error);
    }
};

// @desc    Authenticate a user
// @route   POST /api/auth/login
// @access  Public
const loginUser = async (req, res, next) => {
    try {
        const { email, password } = req.body;

        const user = await User.findOne({ email });

        if (user && (await bcrypt.compare(password, user.password))) {
            res.json({
                _id: user.id,
                name: user.name,
                email: user.email,
                neighborhood: user.neighborhood,
                phone: user.phone,
                profilePhoto: user.profilePhoto,
                bio: user.bio,
                token: generateToken(user._id),
            });
        } else {
            res.status(400);
            return next(new Error('Invalid credentials'));
        }
    } catch (error) {
        next(error);
    }
};

// @desc    Update user profile
// @route   PUT /api/auth/profile
// @access  Private
const updateProfile = async (req, res, next) => {
    try {
        const user = await User.findById(req.user.id);
        if (!user) {
            res.status(404);
            return next(new Error('User not found'));
        }

        user.phone = req.body.phone || user.phone;
        user.neighborhood = req.body.neighborhood || user.neighborhood;
        user.name = req.body.name || user.name;
        user.bio = req.body.bio !== undefined ? req.body.bio : user.bio;
        user.profilePhoto = req.body.profilePhoto || user.profilePhoto;

        if (req.body.password) {
            const salt = await bcrypt.genSalt(10);
            user.password = await bcrypt.hash(req.body.password, salt);
        }

        const updatedUser = await user.save();

        res.json({
            _id: updatedUser.id,
            name: updatedUser.name,
            email: updatedUser.email,
            neighborhood: updatedUser.neighborhood,
            phone: updatedUser.phone,
            profilePhoto: updatedUser.profilePhoto,
            bio: updatedUser.bio,
            token: generateToken(updatedUser._id),
        });
    } catch (error) {
        next(error);
    }
};

// @desc    Get current user profile (also used to verify token)
// @route   GET /api/auth/profile
// @access  Private
const getProfile = async (req, res, next) => {
    try {
        const user = await User.findById(req.user.id).select('-password');
        if (!user) {
            res.status(404);
            return next(new Error('User not found'));
        }
        res.json({
            _id: user.id,
            name: user.name,
            email: user.email,
            neighborhood: user.neighborhood,
            phone: user.phone,
            profilePhoto: user.profilePhoto,
            bio: user.bio,
            createdAt: user.createdAt
        });
    } catch (error) {
        next(error);
    }
};

module.exports = {
    registerUser,
    loginUser,
    updateProfile,
    getProfile,
};
