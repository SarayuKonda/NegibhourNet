const mongoose = require('mongoose');
const dotenv = require('dotenv');
const Item = require('./models/Item');
const User = require('./models/User');

dotenv.config();

const migrate = async () => {
    try {
        await mongoose.connect(process.env.MONGODB_URI);
        console.log('MongoDB Connected for migration...');

        const items = await Item.find({
            $or: [
                { neighborhood: { $exists: false } },
                { neighborhood: '' }
            ]
        }).populate('owner');

        console.log(`Found ${items.length} items to migrate.`);

        for (const item of items) {
            if (item.owner && item.owner.neighborhood) {
                item.neighborhood = item.owner.neighborhood;
                await item.save();
                console.log(`Updated item "${item.title}" with neighborhood "${item.neighborhood}"`);
            } else {
                console.log(`Warning: Item "${item.title}" has no owner neighborhood. Setting default "Unknown".`);
                item.neighborhood = "Unknown";
                await item.save();
            }
        }

        console.log('Migration completed successfully!');
        process.exit(0);
    } catch (error) {
        console.error('Migration failed:', error);
        process.exit(1);
    }
};

migrate();
