const mongoose = require('mongoose');

const connectDB = async () => {
    try {
        const uri = process.env.MONGODB_URI || 'mongodb://localhost:27017/neighborhood-exchange';
        const conn = await mongoose.connect(uri);
        console.log(`MongoDB Connected: ${conn.connection.host}`);
    } catch (error) {
        console.log(`Error: ${error.message}`);
        console.log('Please make sure you have provided a valid MONGODB_URI in your .env file.');
        // process.exit(1);
    }
};

module.exports = connectDB;
