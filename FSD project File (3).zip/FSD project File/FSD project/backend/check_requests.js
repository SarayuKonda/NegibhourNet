const mongoose = require('mongoose');
const dotenv = require('dotenv');
const path = require('path');
const BorrowRequest = require('./models/BorrowRequest');
const Item = require('./models/Item');

dotenv.config({ path: path.join(__dirname, '.env') });

const checkRequests = async () => {
    try {
        await mongoose.connect(process.env.MONGODB_URI);
        console.log('Connected to MongoDB');

        const requests = await BorrowRequest.find({});
        console.log(`Found ${requests.length} requests:`);
        requests.forEach(req => {
            console.log(`Req: Item ${req.item}, Start: ${req.startDate}, End: ${req.endDate}, Cost: ${req.totalCost}, Methods: ${req.paymentMethod}`);
        });

        await mongoose.disconnect();
    } catch (error) {
        console.error('Error:', error);
    }
};

checkRequests();
